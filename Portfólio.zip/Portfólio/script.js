const CHAVE = "mensagensContato";
const CHAVE_INICIALIZADA = "mensagensInicializadas";

function criarMensagensTeste() {
    let mensagens = [];

    for (let i = 1; i <= 20; i++) {
        mensagens.push({
            id: "teste-" + i,
            nome: "Pessoa de teste " + i,
            email: "teste" + i + "@exemplo.com",
            mensagem: "Esta é a mensagem de teste número " + i,
            data: new Date().toISOString()
        });
    }

    return mensagens;
}

function inicializarMensagens() {
    if (localStorage.getItem(CHAVE_INICIALIZADA) !== "sim") {
        let mensagensSalvas = localStorage.getItem(CHAVE);

        if (!mensagensSalvas) {
            localStorage.setItem(CHAVE, JSON.stringify(criarMensagensTeste()));
        }

        localStorage.setItem(CHAVE_INICIALIZADA, "sim");
    }
}

inicializarMensagens();
function buscarMensagens() {
    return JSON.parse(localStorage.getItem(CHAVE)) || [];
}

function salvarMensagens(mensagens) {
    localStorage.setItem(CHAVE, JSON.stringify(mensagens));
}

const formulario = document.getElementById("formContato");

if (formulario) {
    formulario.addEventListener("submit", async function(event) {
        event.preventDefault();

        let nome = document.getElementById("nome").value;
        let email = document.getElementById("email").value;
        let mensagem = document.getElementById("mensagem").value;

        let mensagens = buscarMensagens();

        let novaMensagem = {
            id: Date.now().toString(),
            nome: nome,
            email: email,
            mensagem: mensagem,
            data: new Date().toISOString()
        };

        mensagens.push(novaMensagem);
        salvarMensagens(mensagens);

        try {
            console.log("Enviando primeiro e-mail...");
        
            await emailjs.send(
                "service_5yrkhub",
                "template_80zk0n9",
                { nome: nome, email: email, mensagem: mensagem },
                { publicKey: "gLjgrxI7x-Mgf8vX4" }
            );
        
            console.log("Primeiro e-mail enviado!");
            console.log("E-mail de destino da confirmação:", email);
        
            await emailjs.send(
                "service_5yrkhub",
                "template_q8vhma7",
                { nome: nome, email: email, mensagem: mensagem },
                { publicKey: "gLjgrxI7x-Mgf8vX4" }
            );
        
            console.log("Segundo e-mail enviado!");
        
            document.getElementById("aviso").textContent =
                "Mensagem enviada! Você receberá uma confirmação por e-mail. 💜";
        
        }   
    catch (erro) {
        console.error("Status:", erro.status);
        console.error("Detalhes:", erro.text);
        console.error("Erro completo:", erro);

        document.getElementById("aviso").textContent =
            "A mensagem foi salva, mas ocorreu um erro no envio dos e-mails.";
    }
    formulario.reset();
});
}
const abrirPainel = document.getElementById("abrirPainel");
const fecharPainel = document.getElementById("fecharPainel");
const painelAdmin = document.getElementById("painelAdmin");
const listaMensagens = document.getElementById("listaMensagens");

if (abrirPainel) {
    abrirPainel.addEventListener("click", function() {
        painelAdmin.style.display = "block";
        mostrarMensagens();
    });
}

if (fecharPainel) {
    fecharPainel.addEventListener("click", function() {
        painelAdmin.style.display = "none";
    });
}

function mostrarMensagens() {
    let mensagens = buscarMensagens();

    listaMensagens.innerHTML = "";

    if (mensagens.length === 0) {
        listaMensagens.textContent = "Nenhuma mensagem cadastrada.";
        return;
    }

    mensagens.forEach(function(item) {
        let caixa = document.createElement("div");

        caixa.style.border = "1px solid #ccc";
        caixa.style.padding = "10px";
        caixa.style.margin = "10px 0";

        let nome = document.createElement("p");
        nome.textContent = "Nome: " + item.nome;

        let email = document.createElement("p");
        email.textContent = "E-mail: " + item.email;

        let texto = document.createElement("p");
        texto.textContent = "Mensagem: " + item.mensagem;

        let editar = document.createElement("button");
        editar.textContent = "Editar";
        editar.type = "button";

        editar.addEventListener("click", function() {
            editarMensagem(item.id);
        });

        let excluir = document.createElement("button");
        excluir.textContent = "Excluir";
        excluir.type = "button";

        excluir.addEventListener("click", function() {
            excluirMensagem(item.id);
        });

        caixa.appendChild(nome);
        caixa.appendChild(email);
        caixa.appendChild(texto);
        caixa.appendChild(editar);
        caixa.appendChild(excluir);

        listaMensagens.appendChild(caixa);
    });
}

function editarMensagem(id) {
    let mensagens = buscarMensagens();

    let mensagem = mensagens.find(function(item) {
        return item.id === id;
    });

    if (!mensagem) return;

    let novoNome = prompt("Digite o novo nome:", mensagem.nome);
    if (novoNome === null) return;

    let novoEmail = prompt("Digite o novo e-mail:", mensagem.email);
    if (novoEmail === null) return;

    let novoTexto = prompt("Digite a nova mensagem:", mensagem.mensagem);
    if (novoTexto === null) return;

    mensagem.nome = novoNome;
    mensagem.email = novoEmail;
    mensagem.mensagem = novoTexto;

    salvarMensagens(mensagens);
    mostrarMensagens();

    alert("Mensagem atualizada!");
}

function excluirMensagem(id) {
    let confirmar = confirm("Deseja excluir esta mensagem?");

    if (!confirmar) return;

    let mensagens = buscarMensagens();

    mensagens = mensagens.filter(function(item) {
        return item.id !== id;
    });

    salvarMensagens(mensagens);
    mostrarMensagens();

    alert("Mensagem excluída!");
}